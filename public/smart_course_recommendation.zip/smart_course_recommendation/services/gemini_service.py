"""
Google Gemini AI Service for personalized recommendation explanations,
weekly learning plans, skill-gap coaching, and interactive course Q&A.
Handles missing keys, invalid keys, and quota errors gracefully.
"""

import os
from typing import List, Optional

from config import GEMINI_API_KEY, GEMINI_MODEL
from models.course import Course
from models.recommendation import RecommendationResult
from models.student import Student


class GeminiService:
    """
    Object-Oriented wrapper around the `google-genai` SDK (`gemini-3.8-flash`).
    Provides deterministic analytical fallbacks if GEMINI_API_KEY is not configured.
    """

    def __init__(self, api_key: Optional[str] = None, model_name: Optional[str] = None) -> None:
        self._explicit_key = api_key
        self.model_name = model_name or GEMINI_MODEL or "gemini-3.8-flash"
        self._client = None

    @property
    def api_key(self) -> str:
        key = (
            self._explicit_key
            if self._explicit_key is not None
            else os.getenv("GEMINI_API_KEY", GEMINI_API_KEY)
        ).strip()
        if key in ("YOUR_GEMINI_API_KEY", ""):
            return ""
        return key

    def is_configured(self) -> bool:
        return bool(self.api_key)

    def _get_client(self):
        if not self.is_configured():
            return None
        if self._client is None:
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception:
                return None
        return self._client

    def explain_recommendation(
        self, student: Student, result: RecommendationResult
    ) -> str:
        """Explains why a specific YouTube course was recommended to the student."""
        course = result.course
        b = result.breakdown
        client = self._get_client()
        if client is not None:
            prompt = (
                f"You are an academic AI advisor. In 2-3 concise sentences, explain why "
                f"the YouTube course '{course.title}' by {course.channel_title} ({course.difficulty}, "
                f"{course.duration_formatted}) is recommended for {student.name or 'the student'} "
                f"(Career Goal: {student.career_goal or 'Tech Specialist'}). "
                f"Reference its AI scores: TF-IDF similarity={b.tfidf_cosine_similarity:.2f}, "
                f"Skill-Gap alignment={b.skill_gap_alignment:.2f}, "
                f"Fuzzy compatibility={b.fuzzy_difficulty_compatibility:.2f}, "
                f"Bayesian suitability={b.bayesian_suitability_posterior:.2f}."
            )
            try:
                resp = client.models.generate_content(
                    model=self.model_name, contents=prompt
                )
                if resp and getattr(resp, "text", None):
                    return resp.text.strip()
            except Exception as exc:
                return (
                    f"[Gemini API notice: {exc}]\n\n"
                    f"Analytical Explanation: {result.explanation_summary}"
                )

        return (
            f"Recommended for {student.name or 'your profile'} targeting "
            f"{student.career_goal or 'skill growth'}: {result.explanation_summary}."
        )

    def generate_weekly_study_plan(
        self, student: Student, top_courses: List[Course]
    ) -> str:
        """Generates a structured weekly study schedule tailored to the student's weekly hours."""
        hours = max(2, student.preferences.weekly_study_hours)
        course_titles = [
            f"- {c.title} ({c.channel_title}, {c.duration_formatted})"
            for c in top_courses[:4]
        ]
        courses_block = "\n".join(course_titles) if course_titles else "- Foundational skill modules"

        client = self._get_client()
        if client is not None:
            prompt = (
                f"Create a concise 4-week study plan ({hours} hours/week) for "
                f"{student.name or 'a student'} aiming to become a {student.career_goal or 'Software Engineer'}.\n"
                f"Selected YouTube courses:\n{courses_block}\n"
                f"Include weekly milestones, hands-on practice goals, and review checkpoints."
            )
            try:
                resp = client.models.generate_content(
                    model=self.model_name, contents=prompt
                )
                if resp and getattr(resp, "text", None):
                    return resp.text.strip()
            except Exception as exc:
                return f"Unable to reach Gemini API ({exc}). Showing structured local plan:\n\n" + self._fallback_plan(
                    student, top_courses
                )

        return self._fallback_plan(student, top_courses)

    def answer_career_or_course_question(
        self, student: Student, question: str, context_courses: List[Course]
    ) -> str:
        """Answers a student's question about courses, skills, or career roadmaps."""
        q = (question or "").strip()
        if not q:
            return "Please enter a question about your courses, skills, or career roadmap."

        client = self._get_client()
        if client is not None:
            course_context = "\n".join(
                f"- {c.title} by {c.channel_title} ({c.difficulty}, {c.duration_formatted})"
                for c in context_courses[:5]
            )
            prompt = (
                f"You are an AI Academic & Career Advisor.\n"
                f"Student Name: {student.name or 'Not set'}\n"
                f"Career Goal: {student.career_goal or 'Not set'}\n"
                f"Current Skills: {', '.join(f'{k} ({v.score:.0f}%)' for k, v in student.skills.items()) or 'None yet'}\n"
                f"Available YouTube Courses:\n{course_context or 'None loaded yet'}\n\n"
                f"Question: {q}\n"
                f"Provide a clear, practical, and academically sound response in 3-5 sentences."
            )
            try:
                resp = client.models.generate_content(
                    model=self.model_name, contents=prompt
                )
                if resp and getattr(resp, "text", None):
                    return resp.text.strip()
            except Exception as exc:
                return f"[Gemini API notice: {exc}]\n\n" + self._fallback_answer(
                    student, q, context_courses
                )

        return self._fallback_answer(student, q, context_courses)

    @staticmethod
    def _fallback_plan(student: Student, top_courses: List[Course]) -> str:
        hours = max(2, student.preferences.weekly_study_hours)
        goal = student.career_goal or "AI Engineer"
        c1 = top_courses[0].title if len(top_courses) > 0 else "Core Prerequisite Foundations"
        c2 = top_courses[1].title if len(top_courses) > 1 else "Applied Intermediate Concepts"
        return (
            f"Weekly Study Schedule ({hours} hrs/week) — Target: {goal}\n"
            f"• Week 1 ({hours}h): Complete foundational modules in '{c1}' and take structured concept notes.\n"
            f"• Week 2 ({hours}h): Finish '{c1}' and implement a small standalone coding exercise.\n"
            f"• Week 3 ({hours}h): Begin '{c2}' focusing on problem-solving patterns and prerequisite links.\n"
            f"• Week 4 ({hours}h): Complete hands-on capstone mini-project and update your Skill Proficiency sliders."
        )

    @staticmethod
    def _fallback_answer(
        student: Student, question: str, context_courses: List[Course]
    ) -> str:
        goal = student.career_goal or "your chosen career track"
        first_course = (
            f"'{context_courses[0].title}' by {context_courses[0].channel_title}"
            if context_courses
            else "foundational YouTube courses matching your skill gaps"
        )
        return (
            f"To progress toward {goal}, focus on satisfying prerequisite skills in order using the "
            f"A* Search Learning Roadmap. Based on your current profile, starting with {first_course} "
            f"and allocating {student.preferences.weekly_study_hours} hours per week will build verifiable competency."
        )
